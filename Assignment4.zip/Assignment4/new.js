http = require("http")
fs = require("fs")
url = require("url")
mongoclient = require("mongodb").MongoClient
dburl = "mongodb://127.0.0.1:27017"
http.createServer(function(req,res){
	console.log(req.url)
	myurl = url.parse(req.url)
	console.log(myurl)
	pathname = myurl.pathname
		fs.readFile("form1.html",function(err,data){
			if(err) console.log(err)
			else
			{
				res.write(data)
				res.end()
			}
			
		})
		if(req.method == "POST" && pathname == "/adminform")
			{
				body = []
				req.on("data",function(chunk){
					body.push(chunk)
					
				})
				req.on("end",function(){
					str = body.toString()
					pairs = str.split("&")
					obj = {}
					pairs.forEach(function(pair){
						result = pair.split("=")
						obj[result[0]] = result[1]
						
					})
					
					
				})
				mongoclient.connect(dburl,function(err,client){
					if(err) throw err
					dbo = client.db("mydatabase")
					dbo.collection("WT_Project").insertOne(
					obj,function(err){
						if(err) throw err
						console.log("one document inserted successfully")
						client.close()
					})
					
					
				})
				
				
				
			}
		
	//}
		
}).listen(5000)
console.log("server is running")