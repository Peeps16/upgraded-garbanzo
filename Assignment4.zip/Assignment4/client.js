var fetch=require('node-fetch') 
fetch('http://localhost:8080',{     
    method:'POST', 
    headers:{'Content-type':'application/json'}, 
    
body:JSON.stringify({comp_name:"flipcart",comp_rank:"10",comp_website:"www.flipcart.com",comp_location:"bangalore", comp_size:'100',comp_revenue:'one crores'}) 
}) 
.then((res)=>res.text()) 
.then((text)=>console.log(text)) 
