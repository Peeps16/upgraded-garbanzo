import React from 'react'



export default function Homepage() {
  return (
      <div className = "allpageshome">
            <h1 className='titlehomepage'>House of Flavours</h1>
            <a className='buttonhome' href="/login">Login as User</a>
            <a className='buttonhome' href="/loginown">Login as Admin</a>
      </div>
  )
}
